<?php
// File: itemlist-rest-api.php

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Register REST API endpoint for item list
add_action('rest_api_init', function () {
register_rest_route('jotunheim-magic/v1', '/items', array(
    'methods' => 'GET',
    'callback' => 'fetch_all_items_rest',
    'permission_callback' => '__return_true',
));

});

// Callback function for the REST API endpoint
function fetch_all_items_rest() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'itemlist';
    $items = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    if ($items) {
        return rest_ensure_response($items);
    } else {
        return new WP_Error('no_items', 'No items found', array('status' => 404));
    }
}
?>