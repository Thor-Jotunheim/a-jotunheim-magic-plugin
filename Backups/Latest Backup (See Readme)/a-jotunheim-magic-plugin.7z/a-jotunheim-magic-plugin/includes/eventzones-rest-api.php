<?php
// File: eventzones-rest-api.php

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Register REST API endpoint for event zones
add_action('rest_api_init', function () {
    register_rest_route('jotunheim-magic/v1', '/eventzones', array(
        'methods' => 'GET',
        'callback' => 'fetch_all_eventzones_rest',
        'permission_callback' => '__return_true',
    ));
});

// Callback function for the REST API endpoint
function fetch_all_eventzones_rest() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eventzones';
    $zones = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    if ($zones) {
        return rest_ensure_response($zones);
    } else {
        return new WP_Error('no_zones', 'No event zones found', array('status' => 404));
    }
}