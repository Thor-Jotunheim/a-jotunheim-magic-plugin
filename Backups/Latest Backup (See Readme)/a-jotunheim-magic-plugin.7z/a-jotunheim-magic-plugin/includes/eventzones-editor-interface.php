<?php
// File: eventzones-editor-interface.php

function eventzones_editor_interface() {
    ?>
    <div class="wrap eventzones-editor-container" id="eventzones-editor-container" style="width: 100%; max-width: 1000px; margin: auto; background: url('https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.bhmpics.com%2Fdownloads%2FValheim-Wallpapers%2F77.3-mistlands-teaser-1bb74b243f7219098476.jpg&f=1&nofb=1&ipt=45065e8b7cc5ca3ae8824364501250a2b5b4cf1428e93cd817bd8671ce697ec2&ipo=images') no-repeat fixed center; background-size: cover; filter: brightness(1); padding: 5px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); overflow: hidden; display: flex; gap: 20px; height: auto; min-height: calc(100vh - 50px);">
        
        <div style="flex: 1; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 10px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);">
            <h1 class="eventzones-title" style="font-family: 'MedievalSharp', cursive; font-size: 36px; color: #fff; text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7); text-align: center;">Jotunheim Event Zones Editor</h1>
            <div class="search-section" style="margin-bottom: 5px;">
                <input type="text" id="eventzones-search" placeholder="Search for an event zone..." style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666; margin-bottom: 10px; font-size: 16px;">
                <div id="eventzones-container" style="max-height: calc(100vh - 700px); overflow-y: auto; background: rgba(255, 255, 255, 0.9); padding: 10px; border-radius: 5px;">
                    <!-- Dynamically added checkboxes for event zones -->
                </div>
                <button id="load-zone-btn" style="width: 100%; background: #444; color: #fff; padding: 12px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; margin-top: 10px;">Load Selected Zones</button>
                <button id="clear-selected-zones-btn" style="width: 100%; background: #888; color: #fff; padding: 12px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; margin-top: 10px;">Clear Selected Zones</button>
            </div>
        </div>

        <div style="flex: 2; overflow-y: auto; max-height: calc(100vh - 50px);">
            <div id="edit-sections-container" class="edit-section" style="background: rgba(255, 255, 255, 0.7); padding: 10px; border-radius: 10px; box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);">
                <h3 style="font-family: 'Roboto', sans-serif; font-weight: 700; color: #222; text-align: center;">Edit Zone Details</h3>
                <!-- Edit sections will be dynamically added here -->
            </div>
            <div id="actions-container" style="display: none;">
                <button id="save-zone-btn" style="width: 100%; background: #8B0000; color: #fff; padding: 15px; border: none; border-radius: 5px; font-size: 18px; font-weight: bold; cursor: pointer; margin-top: 20px;">Save Changes</button>
                <button id="delete-zone-btn" style="width: 100%; background: #d9534f; color: #fff; padding: 15px; border: none; border-radius: 5px; font-size: 18px; font-weight: bold; cursor: pointer; margin-top: 20px;">Delete Records</button>
                <div style="margin: 15px auto 0; background: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px; max-width: 300px; text-align: center;">
                    <input type="checkbox" id="confirm-delete-checkbox" style="margin-right: 10px; transform: scale(1.2); cursor: pointer;">
                    <label for="confirm-delete-checkbox" style="font-weight: bold;">Confirm Delete</label>
                </div>
            </div>
        </div>
    </div>

<script type="text/javascript">
var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";

jQuery(document).ready(function ($) {
    function adjustContainerHeight() {
        const windowHeight = $(window).height();
        const containerHeight = windowHeight - $('#eventzones-editor-container').offset().top - 20;
        $('#eventzones-editor-container').css('min-height', containerHeight + 'px');
        $('#eventzones-container').css('max-height', containerHeight - 500 + 'px');
    }

    adjustContainerHeight();
    $(window).resize(function () {
        adjustContainerHeight();
    });

    function refreshZoneList() {
        $.post(ajaxurl, {
            action: 'fetch_all_eventzones'
        }, function (response) {
            if (response.success) {
                $('#eventzones-container').empty();
                response.data.forEach(function (zone) {
                    const checkbox = `<div><label style="display: flex; align-items: center;"><input type="checkbox" class="zone-checkbox" data-id="${zone.id}" value="${zone.name}" style="margin-right: 10px; transform: scale(1.8); cursor: pointer;">${zone.name}</label></div>`;
                    $('#eventzones-container').append(checkbox);
                });
            }
        });
    }

    refreshZoneList();

    $('#eventzones-search').on('input', function () {
        const searchValue = $(this).val();
        if (searchValue.length >= 2) {
            $.post(ajaxurl, {
                action: 'search_eventzones',
                search_value: searchValue
            }, function (response) {
                if (response.success) {
                    $('#eventzones-container').empty();
                    response.data.forEach(function (zone) {
                        const checkbox = `<div><label style="display: flex; align-items: center;"><input type="checkbox" class="zone-checkbox" data-id="${zone.id}" value="${zone.name}" style="margin-right: 10px; transform: scale(1.8); cursor: pointer;">${zone.name}</label></div>`;
                        $('#eventzones-container').append(checkbox);
                    });
                } else {
                    $('#eventzones-container').empty();
                }
            });
        } else {
            refreshZoneList();
        }
    });

    $('#clear-selected-zones-btn').click(function () {
        $('.zone-checkbox:checked').prop('checked', false);
    });

    $('#load-zone-btn').click(function () {
        const selectedZones = [];
        $('.zone-checkbox:checked').each(function () {
            selectedZones.push($(this).data('id'));
        });

        if (selectedZones.length > 0) {
            $('#edit-sections-container').empty();
            $('#actions-container').show();

            selectedZones.forEach(function (zone_id) {
                $.post(ajaxurl, {
                    action: 'fetch_eventzone_details',
                    eventzone_id: zone_id
                }, function (response) {
                    if (response.success) {
                        const zone = response.data;
                        const editSection = `
                            <div class="single-edit-section" style="margin-bottom: 40px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background: rgba(255, 255, 255, 0.8);">
                                <h4 style="font-family: 'Roboto', sans-serif; font-weight: 700; color: #444;">Editing: ${zone.name || ''}</h4>
                                <form class="zone-details-form" data-zone-id="${zone.id}" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; align-items: center;">
                                    <!-- Zone Name -->
                                    <label for="zone-name-${zone.id}" style="font-weight: bold;">Zone Name:</label>
                                    <input type="text" id="zone-name-${zone.id}" name="name" class="zone-name" value="${zone.name || ''}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <!-- Priority -->
                                    <label for="priority-${zone.id}" style="font-weight: bold;">Priority:</label>
                                    <input type="number" id="priority-${zone.id}" name="priority" class="priority" value="${zone.priority || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <!-- Radius -->
                                    <label for="radius-${zone.id}" style="font-weight: bold;">Radius:</label>
                                    <input type="number" step="0.1" id="radius-${zone.id}" name="radius" class="radius" value="${zone.radius || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <!-- Position X, Y, Z -->
                                    <label for="position-x-${zone.id}" style="font-weight: bold;">Position X:</label>
                                    <input type="number" step="0.1" id="position-x-${zone.id}" name="position_x" class="position_x" value="${zone.position_x || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="position-y-${zone.id}" style="font-weight: bold;">Position Y:</label>
                                    <input type="number" step="0.1" id="position-y-${zone.id}" name="position_y" class="position_y" value="${zone.position_y || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="position-z-${zone.id}" style="font-weight: bold;">Position Z:</label>
                                    <input type="number" step="0.1" id="position-z-${zone.id}" name="position_z" class="position_z" value="${zone.position_z || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <!-- Shape -->
                                    <label for="shape-${zone.id}" style="font-weight: bold;">Shape:</label>
                                    <select id="shape-${zone.id}" name="shape" class="shape" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                        <option value="Circle" ${zone.shape === 'Circle' ? 'selected' : ''}>Circle</option>
                                        <option value="Square" ${zone.shape === 'Square' ? 'selected' : ''}>Square</option>
                                    </select>

                                    <!-- Status -->
                                    <label for="eventzone-status-${zone.id}" style="font-weight: bold;">Status:</label>
                                    <select id="eventzone-status-${zone.id}" name="eventzone_status" class="eventzone-status" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                        <option value="enabled" ${zone.eventzone_status === 'enabled' ? 'selected' : ''}>Enabled</option>
                                        <option value="disabled" ${zone.eventzone_status === 'disabled' ? 'selected' : ''}>Disabled</option>
                                    </select>

                                    <!-- Boolean Fields -->
                                    ${['forcePvp', 'godMode', 'ghostMode', 'iceZone', 'noItemLoss', 'noStatLoss', 'noStatGain', 'disableDrops', 'noBuild', 'noShipDamage', 'onlyLeaveViaTeleport', 'respawnOnCorpse', 'respawnAtLocation', 'allowSignUse'].map(field => `
                                        <label for="${field}-${zone.id}" style="font-weight: bold;">${field.charAt(0).toUpperCase() + field.slice(1)}:</label>
                                        <input type="checkbox" id="${field}-${zone.id}" name="${field}" class="${field}" ${zone[field] == 1 ? 'checked' : ''} style="transform: scale(1.8); margin-top: 5px;">
                                    `).join('')}

                                    <!-- Additional numeric fields -->
                                    <label for="zone-height-${zone.id}" style="font-weight: bold;">Zone Height:</label>
                                    <input type="number" step="0.1" id="zone-height-${zone.id}" name="zoneHeight" class="zoneHeight" value="${zone.zoneHeight || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="square-x-radius-${zone.id}" style="font-weight: bold;">Square X Radius:</label>
                                    <input type="number" step="0.1" id="square-x-radius-${zone.id}" name="squareXRadius" class="squareXRadius" value="${zone.squareXRadius || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="square-z-radius-${zone.id}" style="font-weight: bold;">Square Z Radius:</label>
                                    <input type="number" step="0.1" id="square-z-radius-${zone.id}" name="squareZRadius" class="squareZRadius" value="${zone.squareZRadius || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="respawn-location-x-${zone.id}" style="font-weight: bold;">Respawn Location X:</label>
                                    <input type="number" step="0.1" id="respawn-location-x-${zone.id}" name="respawnLocation_x" class="respawnLocation_x" value="${zone.respawnLocation_x || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="respawn-location-y-${zone.id}" style="font-weight: bold;">Respawn Location Y:</label>
                                    <input type="number" step="0.1" id="respawn-location-y-${zone.id}" name="respawnLocation_y" class="respawnLocation_y" value="${zone.respawnLocation_y || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    
                                    <label for="respawn-location-z-${zone.id}" style="font-weight: bold;">Respawn Location Z:</label>
                                    <input type="number" step="0.1" id="respawn-location-z-${zone.id}" name="respawnLocation_z" class="respawnLocation_z" value="${zone.respawnLocation_z || 0}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                </form>
                            </div>
                        `;
                        $('#edit-sections-container').append(editSection);
                    } else {
                        alert('Failed to fetch zone details.');
                    }
                });
            });
        }
    });

    // Save button click handler
    $('#save-zone-btn').click(function () {
        const zonesData = [];

        $('.single-edit-section').each(function () {
            const form = $(this).find('.zone-details-form');
            const zoneData = {
                id: form.data('zone-id'),
                name: form.find('.zone-name').val(),
                priority: parseFloat(form.find('.priority').val()) || 0,
                radius: parseFloat(form.find('.radius').val()) || 0,
                position_x: parseFloat(form.find('.position_x').val()) || 0,
                position_y: parseFloat(form.find('.position_y').val()) || 0,
                position_z: parseFloat(form.find('.position_z').val()) || 0,
                shape: form.find('.shape').val(),
                eventzone_status: form.find('.eventzone-status').val(),
                forcePvp: form.find('.forcePvp').is(':checked') ? 1 : 0,
                godMode: form.find('.godMode').is(':checked') ? 1 : 0,
                ghostMode: form.find('.ghostMode').is(':checked') ? 1 : 0,
                iceZone: form.find('.iceZone').is(':checked') ? 1 : 0,
                noItemLoss: form.find('.noItemLoss').is(':checked') ? 1 : 0,
                noStatLoss: form.find('.noStatLoss').is(':checked') ? 1 : 0,
                noStatGain: form.find('.noStatGain').is(':checked') ? 1 : 0,
                disableDrops: form.find('.disableDrops').is(':checked') ? 1 : 0,
                noBuild: form.find('.noBuild').is(':checked') ? 1 : 0,
                noShipDamage: form.find('.noShipDamage').is(':checked') ? 1 : 0,
                onlyLeaveViaTeleport: form.find('.onlyLeaveViaTeleport').is(':checked') ? 1 : 0,
                respawnOnCorpse: form.find('.respawnOnCorpse').is(':checked') ? 1 : 0,
                respawnAtLocation: form.find('.respawnAtLocation').is(':checked') ? 1 : 0,
                allowSignUse: form.find('.allowSignUse').is(':checked') ? 1 : 0,
                zoneHeight: parseFloat(form.find('.zoneHeight').val()) || 0,
                squareXRadius: parseFloat(form.find('.squareXRadius').val()) || 0,
                squareZRadius: parseFloat(form.find('.squareZRadius').val()) || 0,
                respawnLocation_x: parseFloat(form.find('.respawnLocation_x').val()) || 0,
                respawnLocation_y: parseFloat(form.find('.respawnLocation_y').val()) || 0,
                respawnLocation_z: parseFloat(form.find('.respawnLocation_z').val()) || 0,
            };
            zonesData.push(zoneData);
        });

        $.post(ajaxurl, { action: 'save_eventzone_details', zones_data: zonesData }, function (response) {
            if (response.success) {
                alert('Zones saved successfully.');
            } else {
                alert('Failed to save zones.');
            }
        });
    });

// Delete button handler
$('#delete-zone-btn').click(function () {
    if (!$('#confirm-delete-checkbox').is(':checked')) {
        alert('Please confirm deletion by checking the box.');
        return;
    }

    const selectedZones = [];
    $('.zone-checkbox:checked').each(function () {
        selectedZones.push($(this).data('id'));
    });

    if (selectedZones.length === 0) {
        alert('No zones selected for deletion.');
        return;
    }

    if (confirm('Are you sure you want to delete the selected zones?')) {
        $.post(ajaxurl, {
            action: 'delete_eventzone_details',
            zone_ids: selectedZones
        }, function (response) {
            console.log("Delete response:", response);  // Add this line for debugging
            if (response.success) {
                alert('Selected zones deleted successfully.');
                refreshZoneList();
                $('#edit-sections-container').empty();
                $('#actions-container').hide();
            } else {
                alert('Failed to delete zones. ' + (response.data ? response.data : ''));
            }
        }).fail(function (xhr, status, error) {
            alert('An error occurred while deleting: ' + error);
            console.error("Delete error:", xhr, status, error);  // Log the error for more detail
        });
    }
});
});
</script>
    <?php
}
?>