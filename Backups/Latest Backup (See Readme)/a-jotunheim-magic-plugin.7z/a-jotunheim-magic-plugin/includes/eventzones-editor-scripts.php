<?php
// Prevent direct access
if (!defined('ABSPATH')) exit;

// Include the event zone editor AJAX handlers if necessary
require_once plugin_dir_path(__FILE__) . 'eventzones-editor-scripts.php';
require_once plugin_dir_path(__FILE__) . 'eventzones-editor-interface.php';
require_once plugin_dir_path(__FILE__) . 'eventzones-editor-ajax.php';

// Register shortcode for EventZones Editor
if (!function_exists('eventzones_editor_shortcode')) {
	function eventzones_editor_shortcode() {
    	ob_start();
    	eventzones_editor_interface();
    	return ob_get_clean();
	}
        add_shortcode('eventzones_editor', 'eventzones_editor_shortcode');
}

// Register shortcode for EventZones Add New Zone
if (!function_exists('eventzones_add_new_zone_shortcode')) {
    function eventzones_add_new_zone_shortcode() {
        ob_start();
        jotunheim_magic_add_new_zone_interface();
        return ob_get_clean();
	}
    add_shortcode('eventzones_add_new_zone', 'eventzones_add_new_zone_shortcode');
}