<?php
// AJAX handler for fetching all event zones for the dropdown
function fetch_all_eventzones() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'eventzones';
    $zones = $wpdb->get_results("SELECT id, name FROM $table_name", ARRAY_A);

    if ($zones !== null) {
        wp_send_json_success($zones);
    } else {
        error_log('No event zones found or database query error.');
        wp_send_json_error('No event zones found.');
    }
}
add_action('wp_ajax_fetch_all_eventzones', 'fetch_all_eventzones');
add_action('wp_ajax_nopriv_fetch_all_eventzones', 'fetch_all_eventzones');

// AJAX handler for fetching event zone details
function fetch_eventzone_details() {
    global $wpdb;

    if (!isset($_POST['eventzone_id'])) {
        error_log('eventzone_id not received in fetch_eventzone_details.');
        wp_send_json_error('eventzone_id not received.');
        return;
    }

    $eventzone_id = intval($_POST['eventzone_id']);
    error_log('Received eventzone_id: ' . $eventzone_id);

    if ($eventzone_id <= 0) {
        wp_send_json_error('Invalid eventzone_id.');
        return;
    }

    $table_name = $wpdb->prefix . 'eventzones';
    $zone = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $eventzone_id), ARRAY_A);

    if ($zone !== null) {
        wp_send_json_success($zone);
    } else {
        error_log('Event zone not found for id: ' . $eventzone_id);
        wp_send_json_error('Event zone not found.');
    }
}
add_action('wp_ajax_fetch_eventzone_details', 'fetch_eventzone_details');

// AJAX handler for searching event zones
function search_eventzones() {
    global $wpdb;

    $search_value = isset($_POST['search_value']) ? sanitize_text_field($_POST['search_value']) : '';
    if (empty($search_value)) {
        wp_send_json_error('Search value is empty.');
        return;
    }

    $table_name = $wpdb->prefix . 'eventzones';
    $zones = $wpdb->get_results($wpdb->prepare("SELECT id, name FROM $table_name WHERE name LIKE %s", '%' . $search_value . '%'), ARRAY_A);

    if ($zones !== null) {
        wp_send_json_success($zones);
    } else {
        error_log('No matching event zones found for search: ' . $search_value);
        wp_send_json_error('No matching event zones found.');
    }
}
add_action('wp_ajax_search_eventzones', 'search_eventzones');
add_action('wp_ajax_nopriv_search_eventzones', 'search_eventzones');

// AJAX handler for saving event zone details
function save_eventzone_details() {
    global $wpdb;
    $zones_data = $_POST['zones_data'];

    // Sanitize and prepare data
    foreach ($zones_data as $zone_data) {
        $zone_data = array_map('sanitize_text_field', $zone_data);

        $table_name = $wpdb->prefix . 'eventzones';
        $result = $wpdb->update(
            $table_name,
            array(
                'name' => $zone_data['name'],
                'priority' => intval($zone_data['priority']),
                'radius' => floatval($zone_data['radius']),
                'position_x' => floatval($zone_data['position_x']),
                'position_y' => floatval($zone_data['position_y']),
                'position_z' => floatval($zone_data['position_z']),
                'shape' => $zone_data['shape'],
                'enterText' => $zone_data['enterText'],
                'leaveText' => $zone_data['leaveText'],
                'forcePvp' => intval($zone_data['forcePvp']),
                'godMode' => intval($zone_data['godMode']),
                'ghostMode' => intval($zone_data['ghostMode']),
                'iceZone' => intval($zone_data['iceZone']),
                'noItemLoss' => intval($zone_data['noItemLoss']),
                'noStatLoss' => intval($zone_data['noStatLoss']),
                'noStatGain' => intval($zone_data['noStatGain']),
                'disableDrops' => intval($zone_data['disableDrops']),
                'noBuild' => intval($zone_data['noBuild']),
                'noShipDamage' => intval($zone_data['noShipDamage']),
                'onlyLeaveViaTeleport' => intval($zone_data['onlyLeaveViaTeleport']),
                'respawnOnCorpse' => intval($zone_data['respawnOnCorpse']),
                'respawnAtLocation' => intval($zone_data['respawnAtLocation']),
                'respawnLocation_x' => floatval($zone_data['respawnLocation_x']),
                'respawnLocation_y' => floatval($zone_data['respawnLocation_y']),
                'respawnLocation_z' => floatval($zone_data['respawnLocation_z']),
                'zoneHeight' => floatval($zone_data['zoneHeight']),
                'squareXRadius' => floatval($zone_data['squareXRadius']),
                'squareZRadius' => floatval($zone_data['squareZRadius']),
                'eventzone_status' => $zone_data['eventzone_status'],
                'allowSignUse' => intval($zone_data['allowSignUse'])
            ),
            array('id' => intval($zone_data['id'])) // Update based on zone ID
        );

        if ($result === false) {
            error_log('Failed to update event zone: ' . $zone_data['name']); // Log error for debugging
            wp_send_json_error();
        }
    }

    wp_send_json_success();
}
add_action('wp_ajax_save_eventzone_details', 'save_eventzone_details');
add_action('wp_ajax_nopriv_save_eventzone_details', 'save_eventzone_details');

// AJAX handler for deleting event zone details
function delete_eventzone_details() {
    global $wpdb;

    // Retrieve the list of IDs to delete from the request
    $zone_ids = isset($_POST['zone_ids']) ? $_POST['zone_ids'] : [];

    if (empty($zone_ids)) {
        wp_send_json_error('No zones selected for deletion.');
    }

    // Prepare the table name
    $table_name = $wpdb->prefix . 'eventzones'; // Replace with your actual table name

    // Loop through IDs and delete each one
    $errors = [];
    foreach ($zone_ids as $zone_id) {
        $deleted = $wpdb->delete($table_name, ['id' => intval($zone_id)], ['%d']);
        if ($deleted === false) {
            $errors[] = $zone_id;
        }
    }

    if (empty($errors)) {
        wp_send_json_success('Zones deleted successfully.');
    } else {
        wp_send_json_error('Failed to delete zones with IDs: ' . implode(', ', $errors));
    }
}
add_action('wp_ajax_delete_eventzone_details', 'delete_eventzone_details');