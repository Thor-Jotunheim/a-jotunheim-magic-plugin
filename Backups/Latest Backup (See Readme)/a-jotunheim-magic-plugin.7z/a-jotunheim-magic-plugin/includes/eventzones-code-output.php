<?php
// File: eventzones-code-output.php

// Check if this file is being accessed directly
if (basename($_SERVER['PHP_SELF']) == "eventzones-code-output.php") {
    // Include Highlight.js from a CDN for syntax highlighting
    echo '
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.3.1/styles/monokai.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.3.1/highlight.min.js"></script>
    <script>hljs.highlightAll();</script>

    <style>
        #copy-button {
            margin-bottom: 10px;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 14px;
            border-radius: 5px;
        }
        #copy-button:hover {
            background-color: #45a049;
        }
    </style>

    <button id="copy-button">Copy to Clipboard</button>
    ';

    // JavaScript to copy code to clipboard
    echo '
    <script>
        document.getElementById("copy-button").addEventListener("click", function() {
            var code = document.querySelector("pre code").innerText;
            navigator.clipboard.writeText(code).then(function() {
                alert("Code copied to clipboard!");
            }).catch(function(error) {
                alert("Failed to copy code: " + error);
            });
        });
    </script>
    ';

    // REST API endpoint for event zones
    $api_url = "https://jotun.games/wp-json/jotunheim-magic/v1/eventzones";
    $response = @file_get_contents($api_url);

    if ($response === FALSE) {
        die("Error fetching data from the API. Please check if the API endpoint is accessible.");
    }

    $zones = json_decode($response, true);
    if (!is_array($zones) || empty($zones)) {
        die("No zones found or invalid API response.");
    }

    $zoneNames = []; // Store zone names for final output

    // Wrap output in <pre> and <code> tags for highlight.js
    echo "<pre><code class='language-cs'>\n";

    foreach ($zones as $row) {
        // Skip zones that are disabled based on eventzone_status
        if (isset($row['eventzone_status']) && $row['eventzone_status'] === 'disabled') {
            continue;
        }

        // Define base zone variables
        $name = isset($row['name']) ? $row['name'] : 'Unknown';
        $priority = isset($row['priority']) ? $row['priority'] : 0;

        // Format radius with .0f if no decimal
        $radius = isset($row['radius']) ? ((strpos($row['radius'], '.') === false) ? "{$row['radius']}.0f" : "{$row['radius']}f") : "0.0f";

        // Special handling for "spawn" zone location
        if (strtolower($name) === 'spawn') {
            $location = "JotunheimClient.SpawnLocation";
        } else {
            // Use Vector3 for other zones
            $position_x = isset($row['position_x']) ? ((strpos($row['position_x'], '.') === false) ? "{$row['position_x']}.0f" : "{$row['position_x']}f") : "0.0f";
            $position_y = isset($row['position_y']) ? ((strpos($row['position_y'], '.') === false) ? "{$row['position_y']}.0f" : "{$row['position_y']}f") : "0.0f";
            $position_z = isset($row['position_z']) ? ((strpos($row['position_z'], '.') === false) ? "{$row['position_z']}.0f" : "{$row['position_z']}f") : "0.0f";
            $location = "new Vector3($position_x, $position_y, $position_z)";
        }

        $shape = isset($row['shape']) && $row['shape'] == 'Circle' ? 'ZoneShape.Circle' : 'ZoneShape.Square';

        // Add the zone name to the array for the final output
        $zoneNames[] = $name;

        // Start of Zone definition
        echo "Zone $name = new Zone(\"$name\", $priority, $radius, $location, $shape)\n";
        echo "{\n";

        // Handle text attributes if they exist
        if (!empty($row['enterText'])) echo "    enterText = \"{$row['enterText']}\",\n";
        if (!empty($row['leaveText'])) echo "    leaveText = \"{$row['leaveText']}\",\n";

        // Only output fields with value 1 (as true) and skip fields with 0 or "0"
        foreach ($row as $field => $value) {
            // Skip already processed fields
            if (in_array($field, ['id', 'name', 'priority', 'radius', 'position_x', 'position_y', 'position_z', 'shape', 'enterText', 'leaveText', 'eventzone_status'])) {
                continue;
            }

            // Output boolean fields correctly
            if ($value === 1 || $value === "1") {
                echo "    $field = true,\n";
            } elseif (is_numeric($value) && $value != 0 && $value !== "0") {
                // Add .0f to floating-point fields that lack a decimal point
                if (in_array($field, ['respawnLocation_x', 'respawnLocation_y', 'respawnLocation_z', 'zoneHeight', 'squareXRadius', 'squareZRadius'])) {
                    echo "    $field = " . (strpos($value, '.') === false ? "{$value}.0f" : "{$value}f") . ",\n";
                } else {
                    echo "    $field = $value,\n";
                }
            }
        }

        // Special Vector3 for respawnLocation if provided
        if (!empty($row['respawnLocation_x']) && !empty($row['respawnLocation_y']) && !empty($row['respawnLocation_z'])) {
            echo "    respawnLocation = new Vector3(";
            $respawn_components = [$row['respawnLocation_x'], $row['respawnLocation_y'], $row['respawnLocation_z']];
            foreach ($respawn_components as $index => $component) {
                echo (is_numeric($component) && strpos($component, '.') === false) ? "{$component}.0f" : "{$component}f";
                echo ($index < 2) ? ", " : "";  // Comma between components
            }
            echo "),\n";
        }

        echo "};\n\n"; // End of Zone definition
    }

    // Zones.Add section
    echo "\n// Add zones to the Zones collection\n";
    foreach ($zoneNames as $zoneName) {
        echo "Zones.Add($zoneName);\n";
    }

    echo "</code></pre>\n"; // Close tags for highlight.js
}
?>