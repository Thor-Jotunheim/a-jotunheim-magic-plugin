<?php
// File: eventzones-add-new-zone-interface.php

// Function to display the "Add New Zone" interface
function jotunheim_magic_add_new_zone_interface() {
    ob_start(); // Start output buffering
    ?>
    <div class="single-edit-section" style="margin-bottom: 40px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background: rgba(255, 255, 255, 0.8);">
        <h4 style="font-family: 'Roboto', sans-serif; font-weight: 700; color: #444;">Adding New Event Zone</h4>
        <form id="add-new-zone-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; align-items: center;">
            <input type="hidden" name="action" value="add_jotunheim_zone">
            <?php wp_nonce_field('add_jotunheim_zone_nonce', 'jotunheim_nonce'); ?>

            <!-- Zone Name Field -->
            <label for="zone-name" style="font-weight: bold;">Zone Name:</label>
            <input type="text" name="name" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Priority Field -->
            <label for="priority" style="font-weight: bold;">Priority:</label>
            <input type="number" name="priority" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Radius Field -->
            <label for="radius" style="font-weight: bold;">Radius:</label>
            <input type="number" step="0.1" name="radius" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Position X, Y, Z Fields -->
            <label for="position_x" style="font-weight: bold;">Position X:</label>
            <input type="number" step="0.1" name="position_x" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
            
            <label for="position_y" style="font-weight: bold;">Position Y:</label>
            <input type="number" step="0.1" name="position_y" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
            
            <label for="position_z" style="font-weight: bold;">Position Z:</label>
            <input type="number" step="0.1" name="position_z" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Shape Field -->
            <label for="shape" style="font-weight: bold;">Shape:</label>
            <select name="shape" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                <option value="Circle">Circle</option>
                <option value="Square">Square</option>
            </select>

            <!-- Enter and Leave Text Fields -->
            <label for="enterText" style="font-weight: bold;">Enter Text:</label>
            <input type="text" name="enterText" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="leaveText" style="font-weight: bold;">Leave Text:</label>
            <input type="text" name="leaveText" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Boolean Fields -->
            <?php
            $boolean_fields = ['forcePvp', 'godMode', 'ghostMode', 'iceZone', 'noItemLoss', 'noStatLoss', 'noStatGain', 'disableDrops', 'noBuild', 'noShipDamage', 'onlyLeaveViaTeleport', 'respawnOnCorpse', 'respawnAtLocation', 'allowSignUse'];
            foreach ($boolean_fields as $field) {
                echo "
                <label for='$field' style='font-weight: bold;'>".ucfirst($field).":</label>
                <input type='checkbox' name='$field' style='transform: scale(1.8); margin-top: 5px;'>
                ";
            }
            ?>

            <!-- Zone Height, Square X Radius, Square Z Radius -->
            <label for="zoneHeight" style="font-weight: bold;">Zone Height:</label>
            <input type="number" step="0.1" name="zoneHeight" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="squareXRadius" style="font-weight: bold;">Square X Radius:</label>
            <input type="number" step="0.1" name="squareXRadius" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="squareZRadius" style="font-weight: bold;">Square Z Radius:</label>
            <input type="number" step="0.1" name="squareZRadius" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Respawn Location Fields -->
            <label for="respawnLocation_x" style="font-weight: bold;">Respawn Location X:</label>
            <input type="number" step="0.1" name="respawnLocation_x" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
            
            <label for="respawnLocation_y" style="font-weight: bold;">Respawn Location Y:</label>
            <input type="number" step="0.1" name="respawnLocation_y" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
            
            <label for="respawnLocation_z" style="font-weight: bold;">Respawn Location Z:</label>
            <input type="number" step="0.1" name="respawnLocation_z" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <!-- Submit Button -->
            <input type="submit" name="submit" value="Add Zone" style="grid-column: span 2; padding: 10px; background-color: #0073aa; color: #fff; border: none; border-radius: 5px; cursor: pointer;">
        </form>
    </div>
    <?php
    return ob_get_clean(); // Return the content
}

// Shortcode to display the "Add New Zone" form
add_shortcode('jotunheim_add_new_zone', 'jotunheim_magic_add_new_zone_interface');

// Handle form submission
function jotunheim_magic_handle_add_zone() {
    // Verify nonce
    if (!isset($_POST['jotunheim_nonce']) || !wp_verify_nonce($_POST['jotunheim_nonce'], 'add_jotunheim_zone_nonce')) {
        wp_die('Invalid nonce verification.');
    }

    // Check editor permissions
    if (!current_user_can('update_eventzones')) {
        wp_die('You do not have permission to add zones.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'eventzones';

    // Ensure the correct table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        error_log('Database table does not exist: ' . $table_name);
        wp_die('Database table does not exist. Please ensure the table is created.');
    }    
    
    // Insert data into the table
    $result = $wpdb->insert(
        $table_name,
        array(
            'name' => sanitize_text_field($_POST['name']),
            'priority' => intval($_POST['priority']),
            'radius' => floatval($_POST['radius']),
            'position_x' => floatval($_POST['position_x']),
            'position_y' => floatval($_POST['position_y']),
            'position_z' => floatval($_POST['position_z']),
            'shape' => sanitize_text_field($_POST['shape']),
            'enterText' => sanitize_text_field($_POST['enterText']),
            'leaveText' => sanitize_text_field($_POST['leaveText']),
            'forcePvp' => isset($_POST['forcePvp']) ? 1 : 0,
            'godMode' => isset($_POST['godMode']) ? 1 : 0,
            'ghostMode' => isset($_POST['ghostMode']) ? 1 : 0,
            'iceZone' => isset($_POST['iceZone']) ? 1 : 0,
            'noItemLoss' => isset($_POST['noItemLoss']) ? 1 : 0,
            'noStatLoss' => isset($_POST['noStatLoss']) ? 1 : 0,
            'noStatGain' => isset($_POST['noStatGain']) ? 1 : 0,
            'disableDrops' => isset($_POST['disableDrops']) ? 1 : 0,
            'noBuild' => isset($_POST['noBuild']) ? 1 : 0,
            'noShipDamage' => isset($_POST['noShipDamage']) ? 1 : 0,
            'onlyLeaveViaTeleport' => isset($_POST['onlyLeaveViaTeleport']) ? 1 : 0,
            'respawnOnCorpse' => isset($_POST['respawnOnCorpse']) ? 1 : 0,
            'respawnAtLocation' => isset($_POST['respawnAtLocation']) ? 1 : 0,
            'allowSignUse' => isset($_POST['allowSignUse']) ? 1 : 0,
            'zoneHeight' => floatval($_POST['zoneHeight']),
            'squareXRadius' => floatval($_POST['squareXRadius']),
            'squareZRadius' => floatval($_POST['squareZRadius']),
            'respawnLocation_x' => floatval($_POST['respawnLocation_x']),
            'respawnLocation_y' => floatval($_POST['respawnLocation_y']),
            'respawnLocation_z' => floatval($_POST['respawnLocation_z']),
        )
    );

    if ($result) {
        wp_redirect(add_query_arg('message', 'success', wp_get_referer()));
    } else {
        wp_redirect(add_query_arg('message', 'error', wp_get_referer()));
    }
    exit;
}

// Hooks to handle form submission
add_action('admin_post_nopriv_add_jotunheim_zone', 'jotunheim_magic_handle_add_zone');
add_action('admin_post_add_jotunheim_zone', 'jotunheim_magic_handle_add_zone');
?>