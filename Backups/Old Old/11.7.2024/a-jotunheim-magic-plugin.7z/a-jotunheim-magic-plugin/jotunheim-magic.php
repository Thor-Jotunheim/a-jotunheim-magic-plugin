<?php
// File: jotunheim-magic.php

/*
Plugin Name: A Jotunheim Magic Plugin
Description: A plugin to manage the item list and editor for Jotunheim.
Version: 0.9
Author: Thor
*/

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Include necessary files
include_once(plugin_dir_path(__FILE__) . 'includes/itemlist-editor-scripts.php');
include_once(plugin_dir_path(__FILE__) . 'includes/itemlist-editor-interface.php');
include_once(plugin_dir_path(__FILE__) . 'includes/itemlist-editor-ajax.php');
include_once(plugin_dir_path(__FILE__) . 'includes/itemlist-rest-api.php');
include_once(plugin_dir_path(__FILE__) . 'includes/itemlist-add-new-item-interface.php');
include_once(plugin_dir_path(__FILE__) . 'includes/pricelist.php');
include_once(plugin_dir_path(__FILE__) . 'includes/discord-oauth-handler.php'); // Include OAuth handler
include_once(plugin_dir_path(__FILE__) . 'includes/discord-role-access.php'); // Include role access management

// Register shortcode to add new item
add_shortcode('jotunheim_add_new_item', 'jotunheim_magic_add_new_item_interface');

// Activate the plugin
function jotunheim_magic_activate() {
    error_log('Plugin activated and ready.');
}
register_activation_hook(__FILE__, 'jotunheim_magic_activate');

// Deactivate the plugin
function jotunheim_magic_deactivate() {
    // Any deactivation code here
}
register_deactivation_hook(__FILE__, 'jotunheim_magic_deactivate');

// Function to render Discord Login Button as a shortcode
function jotunheim_magic_discord_login_button() {
    ob_start();
    ?>
    <a href="https://discord.com/api/oauth2/authorize?client_id=1297908076929613956&redirect_uri=https%3A%2F%2Fjotun.games%2Fwp-admin%2Fadmin-ajax.php%3Faction%3Doauth2callback&response_type=code&scope=identify%20email" class="discord-login-button" style="display: inline-block; padding: 10px 20px; background-color: #7289da; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold; text-align: center;">
        Login with Discord
    </a>
    <?php
    return ob_get_clean();
}
add_shortcode('discord_login_button', 'jotunheim_magic_discord_login_button');

// Hook into the WordPress login form to add the "Login with Discord" button
function jotunheim_magic_add_discord_button_to_login() {
    echo do_shortcode('[discord_login_button]');
}
add_action('login_form', 'jotunheim_magic_add_discord_button_to_login');

// Remove WordPress logo from the admin bar for all users
function jotunheim_magic_remove_wp_logo($wp_admin_bar) {
    $wp_admin_bar->remove_node('wp-logo');
}
add_action('admin_bar_menu', 'jotunheim_magic_remove_wp_logo', 999);

// Remove Gutenverse Pro button from the admin bar for all users
function jotunheim_magic_remove_gutenverse_pro_button($wp_admin_bar) {
    $wp_admin_bar->remove_node('gutenverse-pro');
}
add_action('admin_bar_menu', 'jotunheim_magic_remove_gutenverse_pro_button', 999);

// Remove Elementor Overview and WordPress Events & News from the Dashboard for non-admins
function jotunheim_magic_remove_dashboard_widgets() {
    if (!current_user_can('administrator')) {
        remove_meta_box('e-dashboard-overview', 'dashboard', 'normal');
        remove_meta_box('dashboard_primary', 'dashboard', 'side');
    }
}
add_action('wp_dashboard_setup', 'jotunheim_magic_remove_dashboard_widgets');

?>