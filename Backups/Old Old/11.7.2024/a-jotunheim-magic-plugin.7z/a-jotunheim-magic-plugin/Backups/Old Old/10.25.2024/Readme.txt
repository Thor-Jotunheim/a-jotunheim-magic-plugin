This update inlcudes the following
- ItemList record editor
- ItemList add function
- Pricelist via DB, auto-update logic, and section shortcodes
- Discord login integration w/access granted by role