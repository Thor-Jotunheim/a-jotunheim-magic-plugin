<?php 
        /*
        Plugin Name: A Jotunheim Magic Plugin
        Description: A plugin to manage the item list and editor for Jotunheim.
        Version: 0.1
        Author: Thor
        */

        // Prevent direct access
        if (!defined('ABSPATH')) exit;

        // Include the item list editor scripts, interface, and AJAX handlers
        require_once plugin_dir_path(__FILE__) . 'includes/itemlist-editor-scripts.php';
        require_once plugin_dir_path(__FILE__) . 'includes/itemlist-editor-interface.php';
        require_once plugin_dir_path(__FILE__) . 'includes/itemlist-editor-ajax.php';
        require_once plugin_dir_path(__FILE__) . 'includes/itemlist-add-new-item-interface.php'; // Added to include add new item interface

        // Function to create the admin menu
        function jotunheim_magic_admin_menu() {
            add_menu_page(
                'Jotunheim Magic',
                'Jotunheim Magic',
                'manage_options',
                'jotunheim-magic',
                'jotunheim_magic_admin_page',
                'dashicons-admin-generic',
                1 // Set priority to make it show at the top of the list
            );
        }
        add_action('admin_menu', 'jotunheim_magic_admin_menu');

        // Admin page callback
        function jotunheim_magic_admin_page() {
            ?>
            <div class="wrap">
                <h1>Welcome to Jotunheim Magic</h1>
                <p>Manage your item list and editor.</p>
                <p>[itemlist_editor] - Use this shortcode to display the item list editor.</p>
            </div>
            <?php
        }

        // Activate the plugin
        function jotunheim_magic_activate() {
            // Any activation code here
        }
        register_activation_hook(__FILE__, 'jotunheim_magic_activate');

        // Deactivate the plugin
        function jotunheim_magic_deactivate() {
            // Any deactivation code here
        }
        register_deactivation_hook(__FILE__, 'jotunheim_magic_deactivate');