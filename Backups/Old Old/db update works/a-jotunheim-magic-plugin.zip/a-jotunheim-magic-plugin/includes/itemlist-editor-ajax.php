<?php
// itemlist-editor-ajax.php

// AJAX handler for fetching all items for the dropdown
function fetch_all_items() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'itemlist';  // Adjust to match your actual table name
    $items = $wpdb->get_results("SELECT item_name FROM $table_name", ARRAY_A);

    if ($items) {
        wp_send_json_success($items);
    } else {
        wp_send_json_error();
    }
}
add_action('wp_ajax_fetch_all_items', 'fetch_all_items');
add_action('wp_ajax_nopriv_fetch_all_items', 'fetch_all_items');

// AJAX handler for fetching item details
function fetch_item_details() {
    global $wpdb;
    $item_name = sanitize_text_field($_POST['item_name']);
    
    $table_name = $wpdb->prefix . 'itemlist';  // Adjust to match your actual table name
    $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE item_name = %s", $item_name), ARRAY_A);

    if ($item) {
        wp_send_json_success($item);
    } else {
        wp_send_json_error();
    }
}
add_action('wp_ajax_fetch_item_details', 'fetch_item_details');
add_action('wp_ajax_nopriv_fetch_item_details', 'fetch_item_details');

// AJAX handler for searching items
function search_items() {
    global $wpdb;
    $search_value = sanitize_text_field($_POST['search_value']);
    
    $table_name = $wpdb->prefix . 'itemlist';  // Adjust to match your actual table name
    $items = $wpdb->get_results($wpdb->prepare("SELECT item_name FROM $table_name WHERE item_name LIKE %s", '%' . $search_value . '%'), ARRAY_A);

    if ($items) {
        wp_send_json_success($items);
    } else {
        wp_send_json_error();
    }
}
add_action('wp_ajax_search_items', 'search_items');
add_action('wp_ajax_nopriv_search_items', 'search_items');

// AJAX handler for saving item details
function save_item_details() {
    global $wpdb;
    $items_data = $_POST['items_data'];

    // Sanitize and prepare data
    foreach ($items_data as $item_data) {
        $item_data = array_map('sanitize_text_field', $item_data);

        $table_name = $wpdb->prefix . 'itemlist';  // Adjust to match your actual table name
        $result = $wpdb->update(
            $table_name,
            $item_data,
            array('id' => intval($item_data['id']))  // Use item_id instead of item_name for updating
        );

        if ($result === false) {
            error_log('Failed to update item: ' . $item_data['item_name']); // Log error for debugging
            wp_send_json_error();
        }
    }

    wp_send_json_success();
}
add_action('wp_ajax_save_item_details', 'save_item_details');
add_action('wp_ajax_nopriv_save_item_details', 'save_item_details');