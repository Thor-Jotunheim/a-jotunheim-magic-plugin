jQuery(document).ready(function ($) {
    // Adjust container height to ensure the load button is visible
    function adjustContainerHeight() {
        const windowHeight = $(window).height();
        const containerHeight = windowHeight - $('#itemlist-editor-container').offset().top - 20;
        $('#itemlist-editor-container').css('min-height', containerHeight + 'px');
        $('#itemlist-container').css('max-height', containerHeight - 500 + 'px');
    }

    adjustContainerHeight();
    $(window).resize(function () {
        adjustContainerHeight();
    });

    // Load selected item details when the "Load Selected Items" button is clicked
    $('#load-item-btn').click(function () {
        const selectedItems = [];
        $('.item-checkbox:checked').each(function () {
            selectedItems.push($(this).val());
        });

        if (selectedItems.length > 0) {
            $('#edit-sections-container').empty();
            selectedItems.forEach(function (item_name) {
                $.post(ajaxurl, {
                    action: 'fetch_item_details',
                    item_name: item_name
                }, function (response) {
                    if (response.success) {
                        const item = response.data;
                        const editSection = `
                            <div class="single-edit-section" style="margin-bottom: 40px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background: rgba(255, 255, 255, 0.8);">
                                <h4 style="font-family: 'Roboto', sans-serif; font-weight: 700; color: #444;">Editing: ${item.item_name}</h4>
                                <form class="item-details-form" data-item-name="${item.item_name}" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; align-items: center;">
                                    <label for="item-name" style="font-weight: bold;">Item Name:</label>
                                    <input type="text" class="item-name" value="${item.item_name}" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                                    <!-- Additional form fields go here -->
                                </form>
                            </div>
                        `;
                        $('#edit-sections-container').append(editSection);
                    } else {
                        alert('Item not found.');
                    }
                });
            });
        } else {
            alert('Please select at least one item from the list.');
        }
    });

    // Save item details when the "Save Changes" button is clicked
    $('#save-item-btn').click(function () {
        const itemsData = [];

        $('.single-edit-section').each(function () {
            const itemData = {
                item_name: $(this).find('.item-name').val()
                // Additional data fields go here
            };
            itemsData.push(itemData);
        });

        $.post(ajaxurl, {
            action: 'save_item_details',
            items_data: itemsData
        }, function (response) {
            if (response.success) {
                alert('Item details saved successfully for selected items.');
            } else {
                alert('Failed to save item details.');
            }
        });
    });
    });