<?php
/*
Plugin Name: Jotunheim Magic
Description: A plugin to manage the item list and editor for Jotunheim.
Version: 1.0
Author: Your Name
*/

// Prevent direct access
if (!defined('ABSPATH')) exit;

// Include the item list editor scripts, interface, and AJAX handlers
require_once plugin_dir_path(__FILE__) . 'itemlist-editor-scripts.php';
require_once plugin_dir_path(__FILE__) . 'itemlist-editor-interface.php';
require_once plugin_dir_path(__FILE__) . 'itemlist-editor-ajax.php';

// Function to create the admin menu
if (!function_exists('jotunheim_magic_admin_menu')) {
    function jotunheim_magic_admin_menu() {
        add_menu_page(
            'Jotunheim Magic',
            'Jotunheim Magic',
            'manage_options',
            'jotunheim-magic',
            'jotunheim_magic_admin_page',
            'dashicons-admin-generic'
        );
    }
    add_action('admin_menu', 'jotunheim_magic_admin_menu');
}

// Admin page callback
if (!function_exists('jotunheim_magic_admin_page')) {
    function jotunheim_magic_admin_page() {
        ?>
        <div class="wrap">
            <h1>Welcome to Jotunheim Magic</h1>
            <p>Manage your item list and editor.</p>
            <p>[itemlist_editor] - Use this shortcode to display the item list editor.</p>
        </div>
        <?php
    }
}

// Register shortcode for ItemList Editor
if (!function_exists('itemlist_editor_shortcode')) {
    function itemlist_editor_shortcode() {
        ob_start();
        itemlist_editor_interface();
        return ob_get_clean();
    }
    add_shortcode('itemlist_editor', 'itemlist_editor_shortcode');
}

// Activate the plugin
if (!function_exists('jotunheim_magic_activate')) {
    function jotunheim_magic_activate() {
        // Any activation code here
    }
    register_activation_hook(__FILE__, 'jotunheim_magic_activate');
}

// Deactivate the plugin
if (!function_exists('jotunheim_magic_deactivate')) {
    function jotunheim_magic_deactivate() {
        // Any deactivation code here
    }
    register_deactivation_hook(__FILE__, 'jotunheim_magic_deactivate');
}