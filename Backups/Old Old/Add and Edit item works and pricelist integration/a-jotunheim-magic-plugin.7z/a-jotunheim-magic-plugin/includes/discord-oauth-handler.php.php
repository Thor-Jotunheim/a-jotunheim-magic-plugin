<?php
// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Hook into AJAX to handle the Discord OAuth2 callback
add_action('wp_ajax_oauth2callback', 'jotunheim_magic_handle_discord_oauth2_callback');
add_action('wp_ajax_nopriv_oauth2callback', 'jotunheim_magic_handle_discord_oauth2_callback');

function jotunheim_magic_handle_discord_oauth2_callback() {
    if (!isset($_GET['code'])) {
        wp_die('Invalid request');
    }

    $code = sanitize_text_field($_GET['code']);
    $client_id = '1297908076929613956';  // Your Discord Client ID
    $client_secret = 'YOUR_CLIENT_SECRET'; // Your Discord Client Secret
    $redirect_uri = 'https://jotun.games/wp-admin/admin-ajax.php?action=oauth2callback';

    // Exchange the authorization code for an access token
    $response = wp_remote_post('https://discord.com/api/oauth2/token', array(
        'body' => array(
            'client_id' => $client_id,
            'client_secret' => $client_secret,
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $redirect_uri,
        ),
    ));

    if (is_wp_error($response)) {
        wp_die('Failed to communicate with Discord.');
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($body['access_token'])) {
        wp_die('Failed to get access token.');
    }

    $access_token = sanitize_text_field($body['access_token']);

    // Get user information from Discord
    $user_response = wp_remote_get('https://discord.com/api/users/@me', array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $access_token,
        ),
    ));

    if (is_wp_error($user_response)) {
        wp_die('Failed to get user information from Discord.');
    }

    $user_data = json_decode(wp_remote_retrieve_body($user_response), true);

    if (isset($user_data['id'])) {
        // Here you can log the user in, create a WordPress user, etc.
        // For example:
        $username = 'discord_' . sanitize_text_field($user_data['id']);
        $user_id = username_exists($username);

        if (!$user_id) {
            // Create a new user if it doesn't exist
            $random_password = wp_generate_password(12, false);
            $user_id = wp_create_user($username, $random_password, $user_data['email'] ?? '');
        }

        // Log the user in
        wp_set_auth_cookie($user_id);
        wp_redirect(home_url());
        exit;
    }

    wp_die('Unable to log in.');
}