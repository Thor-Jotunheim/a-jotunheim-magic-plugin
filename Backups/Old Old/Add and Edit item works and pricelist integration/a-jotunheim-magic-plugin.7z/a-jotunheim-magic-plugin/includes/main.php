<?php
// main.php

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Enqueue scripts and styles specific to ItemList Editor
require_once plugin_dir_path(__FILE__) . 'includes/itemlist-editor-scripts.php';

// ItemList Editor interface function
require_once plugin_dir_path(__FILE__) . 'includes/itemlist-editor-interface.php';

// Register shortcode for ItemList Editor
add_shortcode('itemlist_editor', 'itemlist_editor_interface');

// AJAX handlers for the item list operations
require_once plugin_dir_path(__FILE__) . 'includes/itemlist-editor-ajax.php';