<?php
    // itemlist-add-new-item-interface.php

    // Function to display the "Add New Item" interface
    function add_new_item_interface() {
    ?>
    <div class="single-edit-section" style="margin-bottom: 40px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background: rgba(255, 255, 255, 0.8);">
        <h4 style="font-family: 'Roboto', sans-serif; font-weight: 700; color: #444;">Adding New Item</h4>
        <form class="item-details-form" data-item-id="" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; align-items: center;">
            <label for="item-name" style="font-weight: bold;">Item Name:</label>
            <input type="text" class="item-name" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
            
            <label for="tech-name" style="font-weight: bold;">Tech Name:</label>
            <select class="tech-name" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                <option value="N/A" selected>N/A</option>
                <option value="Meadow">Meadow</option>
                <option value="Forest">Forest</option>
                <option value="Ocean">Ocean</option>
                <option value="Swamp">Swamp</option>
                <option value="Mountain">Mountain</option>
                <option value="Plains">Plains</option>
                <option value="Mistlands">Mistlands</option>
                <option value="Ashlands">Ashlands</option>
                <option value="Deep North">Deep North</option>
            </select>

            <label for="item-type" style="font-weight: bold;">Item Type:</label>
            <select class="item-type" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
                <option value="Currency">Currency</option>
                <option value="Untradable">Untradable</option>
                <option value="Raw Food">Raw Food</option>
                <option value="Cooked Food">Cooked Food</option>
                <option value="Fish">Fish</option>
                <option value="Seeds">Seeds</option>
                <option value="Bait">Bait</option>
                <option value="Mead">Mead</option>
                <option value="Building & Crafting">Building & Crafting</option>
                <option value="Boss Summons">Boss Summons</option>
                <option value="Tamed Animals">Tamed Animals</option>
                <option value="Armor Sets">Armor Sets</option>
                <option value="Armor">Armor</option>
                <option value="Ammunition">Ammunition</option>
                <option value="Weapons">Weapons</option>
                <option value="Tools">Tools</option>
                <option value="Shields">Shields</option>
                <option value="Trophies">Trophies</option>
                <option value="Crafting Components">Crafting Components</option>
            </select>

            <label for="stack-size" style="font-weight: bold;">Stack Size:</label>
            <input type="number" class="stack-size" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
            
            <label for="undercut" style="font-weight: bold;">Can Be Undercut:</label>
            <input type="checkbox" class="undercut" style="transform: scale(1.8); margin-top: 5px;">

            <label for="unit-price" style="font-weight: bold;">Unit Price:</label>
            <input type="number" step="0.01" class="unit-price" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="lv2-price" style="font-weight: bold;">Lv 2 Price:</label>
            <input type="number" step="0.01" class="lv2-price" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="lv3-price" style="font-weight: bold;">Lv 3 Price:</label>
            <input type="number" step="0.01" class="lv3-price" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="lv4-price" style="font-weight: bold;">Lv 4 Price:</label>
            <input type="number" step="0.01" class="lv4-price" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="lv5-price" style="font-weight: bold;">Lv 5 Price:</label>
            <input type="number" step="0.01" class="lv5-price" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">

            <label for="prefab-name" style="font-weight: bold;">Prefab Name:</label>
            <input type="text" class="prefab-name" value="" style="width: 100%; padding: 10px; border-radius: 5px; border: 2px solid #666;">
        </form>
    </div>
    <?php
    }
    ?>