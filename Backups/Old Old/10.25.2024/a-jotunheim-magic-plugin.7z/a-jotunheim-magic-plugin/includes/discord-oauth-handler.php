<?php
// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Hook into AJAX to handle the Discord OAuth2 callback
add_action('wp_ajax_oauth2callback', 'jotunheim_magic_handle_discord_oauth2_callback');
add_action('wp_ajax_nopriv_oauth2callback', 'jotunheim_magic_handle_discord_oauth2_callback');

function jotunheim_magic_handle_discord_oauth2_callback() {
    if (!isset($_GET['code'])) {
        wp_die('Invalid request');
    }

    $code = sanitize_text_field($_GET['code']);
    $client_id = '1297908076929613956';  // Your Discord Client ID
    $client_secret = 'WzapYHJlj3P0XgwsBC9GATzrSs1kwi4z'; // Your Discord Client Secret
    $redirect_uri = 'https://jotun.games/wp-admin/admin-ajax.php?action=oauth2callback';

    // Exchange the authorization code for an access token
    $response = wp_remote_post('https://discord.com/api/oauth2/token', array(
        'body' => array(
            'client_id' => $client_id,
            'client_secret' => $client_secret,
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $redirect_uri,
        ),
    ));

    if (is_wp_error($response)) {
        wp_die('Failed to communicate with Discord.');
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (!isset($body['access_token'])) {
        wp_die('Failed to get access token.');
    }

    $access_token = sanitize_text_field($body['access_token']);

    // Get user information from Discord
    $user_response = wp_remote_get('https://discord.com/api/users/@me', array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $access_token,
        ),
    ));

    if (is_wp_error($user_response)) {
        wp_die('Failed to get user information from Discord.');
    }

    $user_data = json_decode(wp_remote_retrieve_body($user_response), true);
    if (!isset($user_data['id'])) {
        wp_die('Failed to get user information.');
    }

    $discord_user_id = sanitize_text_field($user_data['id']);
    $username = 'discord_' . $discord_user_id;

    // Get user's nickname from the guild (server)
    $guild_id = '816387080334737436';  // Your Discord server (guild) ID
    $guild_member_response = wp_remote_get("https://discord.com/api/guilds/{$guild_id}/members/{$discord_user_id}", array(
        'headers' => array(
            'Authorization' => 'Bot MTI5NzkwODA3NjkyOTYxMzk1Ng.GrCF_s.Alz6b563skzSJIHDIwoKlR3bTok4S6W1dvIcMc',
        ),
    ));

    if (!is_wp_error($guild_member_response)) {
        $guild_member_data = json_decode(wp_remote_retrieve_body($guild_member_response), true);
        if (isset($guild_member_data['nick']) && !empty($guild_member_data['nick'])) {
            $username = sanitize_text_field($guild_member_data['nick']);
        } elseif (isset($user_data['username'])) {
            $username = sanitize_text_field($user_data['username']);
        }
    } else {
        // If fetching the guild member data fails, fallback to Discord username
        $username = sanitize_text_field($user_data['username']);
    }

    // Create or update user in WordPress
    $user_id = username_exists($username);

    if (!$user_id) {
        // Create a new user if it doesn't exist
        $random_password = wp_generate_password(12, false);
        $user_id = wp_create_user($username, $random_password, $user_data['email'] ?? '');
    }

    // Assign roles based on Discord server roles
    $roles = $guild_member_data['roles'] ?? [];

    if (in_array('816462309274419250', $roles)) {
        // Admin role
        $wp_role = 'editor';
    } elseif (in_array('816452821208793128', $roles)) {
        // Moderator role
        $wp_role = 'moderator';
    } elseif (in_array('888273935282626580', $roles)) {
        // Chosen role
        $wp_role = 'subscriber';
    } elseif (in_array('Banned', $roles) || in_array('Thrall', $roles)) {
        // Banned or Thrall role
        $wp_role = 'view_only';
    } else {
        // Default to view only role
        $wp_role = 'view_only';
    }

    // For Thor and Odin, assign administrator role
    if ($discord_user_id === '859390316410306560' || $discord_user_id === '190645182235017217') {
        $wp_role = 'administrator';
    }

    // Assign additional WordPress roles for Valkyrie and Vithar roles
    if (in_array('ValkyrieRoleID', $roles)) { // Replace 'ValkyrieRoleID' with the actual Discord role ID for Valkyrie
        wp_add_user_role($user_id, 'valkyrie');
    }

    if (in_array('VitharRoleID', $roles)) { // Replace 'VitharRoleID' with the actual Discord role ID for Vithar
        wp_add_user_role($user_id, 'vithar');
    }

    $user = new WP_User($user_id);
    $user->set_role($wp_role);

    // Log the user in
    wp_set_auth_cookie($user_id);
    wp_redirect(home_url());
    exit;
}

// Create the custom roles if they don't exist
function create_custom_roles() {
    if (!get_role('view_only')) {
        add_role('view_only', 'View Only', array(
            'read' => true, // Only allows viewing content, no posting or other capabilities
        ));
    }

    if (!get_role('moderator')) {
        add_role('moderator', 'Moderator', array(
            'read' => true,
            'edit_posts' => true,
        ));
    }

    if (!get_role('valkyrie')) {
        add_role('valkyrie', 'Valkyrie', array(
            'read' => true,
        ));
    }

    if (!get_role('vithar')) {
        add_role('vithar', 'Vithar', array(
            'read' => true,
        ));
    }
}
add_action('init', 'create_custom_roles');